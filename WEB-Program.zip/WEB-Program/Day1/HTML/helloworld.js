//for loop

for(let i=0;i>10;i++){
    console.log("welcome",i);
}

let i = 0;
while(i<10){
    if (i % 2 !== 0) console.log(i);
    i++
}



//for,while,do, while , for,in , for of
function prime(number){
    for(let num=2; num <= number; num++){
        let count=0;
        
    }



}
prime(5)
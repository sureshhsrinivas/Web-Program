package com.SpringExample.SpringFirstClass;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication//main method
public class SpringFirstClassApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringFirstClassApplication.class, args);
	}

}

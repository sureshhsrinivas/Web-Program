package com.jsp.demo.demo.models;

import com.Student;


import org.springframework.stereotype.Repository;

@Repository
public class Model {
    public void insert(Student student){

    }
}

package com;

public class Student {
    public String name;
    String college;
    String branch;
    public Student(String name, String college, String branch){
        this.name= name;
        this.college= college;
        this.branch= branch;
    }
    
}

package com.SpringDemoDay7.Bootdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoProjectDay7ApplicationTests {

	@Test
	void contextLoads() {
	}

}

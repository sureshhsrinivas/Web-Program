package com.SpringDemoDay7.Bootdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoProjectDay7Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoProjectDay7Application.class, args);
	}

}

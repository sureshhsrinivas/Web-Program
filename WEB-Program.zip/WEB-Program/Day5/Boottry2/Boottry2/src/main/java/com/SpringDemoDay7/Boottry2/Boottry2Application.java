package com.SpringDemoDay7.Boottry2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Boottry2Application {

	public static void main(String[] args) {
		SpringApplication.run(Boottry2Application.class, args);
	}

}

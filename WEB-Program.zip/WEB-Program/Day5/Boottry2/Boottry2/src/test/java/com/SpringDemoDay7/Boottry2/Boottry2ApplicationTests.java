package com.SpringDemoDay7.Boottry2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Boottry2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
